# Program for computing the height of a ball in vertical motion

v0 = 5             # Initial velocity
g = 9.81           # Acceleration of gravity
t = 0.6            # Time

y = v0*t        # Vertical position

print( y)
