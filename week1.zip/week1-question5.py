# -*- coding: utf-8 -*-
"""
Created on Fri Jan 21 16:42:35 2022
compute.maximum.height
@author: nalidadi
"""

v0 = 5             # Initial velocity
g = 9.81           # Acceleration of gravity

ymax=0             # maximum y
i=0
Y=[]

for k in range(0,2000):
    t=k/1000
    y = v0*t - 0.5*g*t**2
    print(y)
    Y.append(y)
  
for i in range(1,len(Y),1):
    if ymax<=Y[i]:
        ymax=Y[i]


for k in range(1,len(Y),1):
    if Y[k]==ymax:
        j=k+1
        tmax=j*0.001 

print('the maximum y is',ymax,'in t=',tmax)
