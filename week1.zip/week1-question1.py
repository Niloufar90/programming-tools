# -*- coding: utf-8 -*-
"""
Created on Thu Jan 20 11:51:59 2022
...compute.sum.with.for.loop
@author: nalidadi
"""

x=0
n=10

for i in range(n):
    
    x+=5*i
    print(i,'of',n,'x',x)
print('final.value of x after %i iterations='%(n),x)
print('final.value of x after %i iterations=%5.2f'%(n,x))
