# -*- coding: utf-8 -*-
"""
Created on Sat Jan 22 16:44:25 2022
compute.divisors.using.function
@author: nalidadi
"""

def my_divisor(n):
    d=[]
    for i in range(2,9):
        if n%i==0 and n!=i:
            d.append(i)

    return(d)

d=my_divisor(10)
if len(d)==0:
    print("There is no divisor")
else:
    print(d)



     