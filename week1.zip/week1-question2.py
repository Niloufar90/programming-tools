# -*- coding: utf-8 -*-
"""
Created on Thu Jan 20 12:11:47 2022
compute.number.pi.using.leibniz.method
@author: nalidadi
"""
import numpy

#n=10
def my_pi(max_iter):
    sum_pi=0
    for k in range(max_iter):
        sum_pi+=1/((4*k+1)*(4*k+3))
        sum_pi*=8
    return sum_pi
    
for n in [10,50,100,1000]:
        sum_pi=my_pi(n)
        print('my pi appox=',sum_pi)
        print('error=',abs(sum_pi-numpy.pi),'after %i iteratios'%(n))
    
        print(my_pi(10000))

